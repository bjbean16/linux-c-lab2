#include <stdio.h>
#include <string.h>

struct Person {
    char name[50];
    int age;
};

void add_contact() {
    struct Person p;
    printf("Enter name: ");
    scanf("%s", p.name);
    printf("Enter age: ");
    scanf("%d", &p.age);
    FILE *file = fopen("contacts.txt", "a");
    fprintf(file, "%s %d\n", p.name, p.age);
    fclose(file);
    printf("Contact added: %s, %d\n", p.name, p.age);
}

void view_contacts() {
    struct Person p;
    FILE *file = fopen("contacts.txt", "r");
    if (!file) { printf("No contacts yet.\n"); return; }
    while (fscanf(file, "%s %d", p.name, &p.age) != EOF) {
        printf("%s, %d\n", p.name, p.age);
    }
    fclose(file);
}

int main() {
    int choice;
    while (1) {
        printf("\n1. Add contact\n2. View contacts\n3. Exit\nChoice: ");
        scanf("%d", &choice);
        if (choice == 1) add_contact();
        else if (choice == 2) view_contacts();
        else break;
    }
    return 0;
}
